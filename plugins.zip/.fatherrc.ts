import { defineConfig } from 'father';

export default defineConfig({
  cjs: {},
});
