# umi-plugin-build-zip

umijs 插件，将生成的dist目录打包成dist.zip,不包含dist目录

## Install

```bash
pnpm i umi-plugin-demo -D
```

## Usage

Configure in `.umirc.ts`,

```js
export default {
  plugins: [
    'umi-plugin-build-zip',
  ],
}
```

## LICENSE

MIT
