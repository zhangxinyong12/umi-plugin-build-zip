# 发布npm包流程
## 打包
记得修改package.json中的版本号 

```bash
npm run build
```
##　登录npm

```bash
npm login
```

## 发布

```bash
npm publish
```